/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class employee{
    public:
        int id;
        string name;
        float salary;
        employee(int id,string name,float salary){
            this->id=id;
            this->name=name;
            this->salary=salary;
        }
        void display(){
            cout<<id<<""<<name<<""<<salary<<endl;
        }
};
int main(){
    employee e1=employee(101, "manu", 90000);
    employee e2=employee(201, "mamatha", 95000);
    e1.display();
    e2.display();
    return 0;
}



