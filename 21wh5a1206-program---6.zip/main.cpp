/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
int my_variable = 10; // globalvariable my_variable
int main(){
    int my_variable = 100; //local variable my_variable
    cout<<"value of global my_variable is"<<::my_variable<<endl;
    cout<<"value of local my_variable is"<<my_variable<<endl;
    return 0;
}
