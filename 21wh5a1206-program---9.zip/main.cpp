/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
class test{
    public:
        int y,z;
    test(){
        y = 7;
        z = 13;
    }
    ~test(){}
};
int main()
{
    test a;
    cout<<"the sum is:"<<a.y + a.z;
    return 0;
}
