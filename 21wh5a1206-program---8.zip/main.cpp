/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
class Box{
    private:
        int length;
    public:
        Box():length(0){}
    friend int len(Box); //friend function
};
int len(Box b)
{
    b.length +=10;
    return b.length;
}
int main()
{
    Box b;
    cout<<"Length of box:"<<len(b)<<endl;
    return 0;
}