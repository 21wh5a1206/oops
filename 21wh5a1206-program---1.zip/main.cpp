/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<string.h>
using namespace std;
class Student
{
    string sname;
    int rollno;
    char grade;
    public:void read()
    {
        cin>>sname;
        cin>>rollno;
        cin>>grade;
    }
    void display()
    {
        cout<<"\nName:"<<sname;
        cout<<"\nRollno:"<<rollno;
        cout<<"\nGrade:"<<grade;
    }
};
int main()
{
    int i;
    Student s[3];
    for(i=0;i<3;i++)
    {
        cout<<"Student details:"<<endl;
        s[i].read();
    }
    for(i=0;i<3;i++)
    {
        s[i].display();
    }
    return 0;
}