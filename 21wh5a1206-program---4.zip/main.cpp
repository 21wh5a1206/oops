/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string.h>
using namespace std;
struct Student
{
    string sname,branch;
    int rollno,marks;
};
int main()
{
    Student s1;
    cout<<"Enter details:";
    cout<<"\nName of the Student:";
    cin>>s1.sname;
    cout<<"Student Rollno:";
    cin>>s1.rollno;
    cout<<"Student Marks:";
    cin>>s1.marks;
    cout<<"Student Branch:";
    cin>>s1.branch;
    return 0;
}

